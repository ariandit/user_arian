<?php
$host = "localhost";
$user = "root";
$pass = "";
$db   = "db_bakesbangpol";

$conn = mysqli_connect($host, $user, $pass, $db);

if (!$conn) {
    die("Koneksi Database Gagal: " . mysqli_connect_error());
}

// Set charset ke UTF-8
mysqli_set_charset($conn, "utf8mb4");
?>