<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bakesbangpol Kota Salatiga</title>
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <style>
        :root {
            --primary-color: #0d3b66;
            --accent-color: #f4d35e;
        }
        .bg-primary-custom { background-color: var(--primary-color); }
        .btn-primary-custom { background-color: var(--primary-color); color: #fff; }
        .btn-primary-custom:hover { background-color: #092847; color: #fff; }
        .hero-section {
            background: linear-gradient(rgba(13, 59, 102, 0.85), rgba(13, 59, 102, 0.85)), url('https://images.unsplash.com/photo-1577495508048-b635879837f1?auto=format&fit=crop&w=1200&q=80') center/cover;
            color: white;
            padding: 80px 0;
        }
        .card-service { transition: transform 0.2s; border: none; }
        .card-service:hover { transform: translateY(-5px); }
    </style>
</head>
<body>

<!-- Navigation Bar -->
<nav class="navbar navbar-expand-lg navbar-dark bg-primary-custom sticky-top shadow-sm">
    <div class="container">
        <a class="navbar-brand d-flex align-items-center gap-2" href="index.php">
            <img src="https://upload.wikimedia.org/wikipedia/commons/1/1a/Lambang_Kota_Salatiga.png" alt="Logo Salatiga" width="40" height="48">
            <div>
                <strong class="d-block leading-none">BAKESBANGPOL</strong>
                <small style="font-size: 0.75rem;">KOTA SALATIGA</small>
            </div>
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item"><a class="nav-link active" href="index.php">Beranda</a></li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" data-bs-toggle="dropdown">Profil</a>
                    <ul class="dropdown-menu">
                        <li><a class="dropdown-item" href="#">Visi & Misi</a></li>
                        <li><a class="dropdown-item" href="#">Struktur Organisasi</a></li>
                    </ul>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" data-bs-toggle="dropdown">Layanan Online</a>
                    <ul class="dropdown-menu">
                        <li><a class="dropdown-item" href="/uploads/pengajuan.php">Izin Penelitian / Magang</a></li>
                        <li><a class="dropdown-item" href="#">Pendaftaran Ormas</a></li>
                        <li><a class="dropdown-item" href="#">Surat Keterangan Parpol</a></li>
                    </ul>
                </li>
                <li class="nav-item"><a class="nav-link" href="#">PPID</a></li>
                <li class="nav-item"><a class="nav-link" href="#">Kontak</a></li>
            </ul>
        </div>
    </div>
</nav>