<footer class="bg-primary-custom text-white pt-5 pb-3 mt-5">
    <div class="container">
        <div class="row g-4">
            <div class="col-md-5">
                <h5>Bakesbangpol Kota Salatiga</h5>
                <p class="small text-light">Jl. Letjend. Sukowati No. 51, Kalicacing, Kec. Sidomukti, Kota Salatiga, Jawa Tengah 50724</p>
                <p class="small mb-1"><i class="fas fa-phone me-2"></i> (0298) 321xxx</p>
                <p class="small"><i class="fas fa-envelope me-2"></i> kesbangpol@salatiga.go.id</p>
            </div>
            <div class="col-md-3">
                <h5>Tautan Cepat</h5>
                <ul class="list-unstyled small">
                    <li><a href="#" class="text-white-50 text-decoration-none">Pemerintah Kota Salatiga</a></li>
                    <li><a href="#" class="text-white-50 text-decoration-none">E-PPID Kota Salatiga</a></li>
                    <li><a href="#" class="text-white-50 text-decoration-none">Survei Kepuasan Masyarakat</a></li>
                </ul>
            </div>
            <div class="col-md-4">
                <h5>Jam Pelayanan</h5>
                <p class="small text-light mb-1">Senin - Kamis: 07.00 - 15.30 WIB</p>
                <p class="small text-light">Jumat: 07.00 - 14.00 WIB</p>
            </div>
        </div>
        <hr class="border-secondary my-4">
        <div class="text-center small text-white-50">
            &copy; <?= date('Y'); ?> Badan Kesatuan Bangsa dan Politik Kota Salatiga. Hak Cipta Dilindungi.
        </div>
    </div>
</footer>

<!-- Bootstrap 5 JS Bundle -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>