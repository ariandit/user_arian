<?php
header('Content-Type: application/json');
require_once '../koneksi.php';

$kode = isset($_GET['kode']) ? trim($_GET['kode']) : '';

if (empty($kode)) {
    echo json_encode(['status' => 'error', 'message' => 'Masukkan nomor tiket permohonan.']);
    exit;
}

// Prepared Statement untuk mencegah SQL Injection
$stmt = mysqli_prepare($conn, "SELECT nama_pemohon, jenis_layanan, status, created_at FROM permohonan WHERE nomor_tiket = ?");
mysqli_stmt_bind_param($stmt, "s", $kode);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

if ($row = mysqli_fetch_assoc($result)) {
    echo json_encode([
        'status' => 'success',
        'nama' => htmlspecialchars($row['nama_pemohon']),
        'layanan' => htmlspecialchars($row['jenis_layanan']),
        'posisi_berkas' => htmlspecialchars($row['status']),
        'tanggal' => date('d-m-Y H:i', strtotime($row['created_at']))
    ]);
} else {
    echo json_encode(['status' => 'error', 'message' => 'Nomor tiket tidak ditemukan dalam sistem.']);
}

mysqli_stmt_close($stmt);
mysqli_close($conn);
?>