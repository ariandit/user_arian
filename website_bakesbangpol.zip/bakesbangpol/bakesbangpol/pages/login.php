<?php 
require_once __DIR__ . '/../config/koneksi.php';
require_once __DIR__ . '/../includes/header.php'; 
?>

<div class="container my-5">
    <div class="row justify-content-center">
        <div class="col-md-4">
            <div class="card shadow border-0 rounded-3 p-4">
                <h4 class="fw-bold text-center text-primary mb-3">Masuk Akun</h4>

                <?php if (isset($_SESSION['error'])): ?>
                    <div class="alert alert-danger py-2 small"><?= $_SESSION['error']; unset($_SESSION['error']); ?></div>
                <?php endif; ?>

                <form action="../modules/proses_login.php" method="POST">
                    <div class="mb-3">
                        <label class="form-label fw-bold small">Email / Username</label>
                        <input type="text" name="login_input" class="form-control" placeholder="Email atau Username Admin" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-bold small">Password</label>
                        <input type="password" name="password" class="form-control" placeholder="Password" required>
                    </div>
                    <button type="submit" class="btn btn-primary w-100 fw-bold">Masuk</button>
                </form>
                <div class="text-center mt-3 small">
                    Belum punya akun? <a href="register.php">Daftar sekarang</a>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>