<?php 
require_once __DIR__ . '/../config/koneksi.php';
require_once __DIR__ . '/../includes/header.php'; 
?>

<div class="container my-5">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card shadow-sm border-0 rounded-3 p-4">
                <h4 class="fw-bold mb-3 text-primary"><i class="fas fa-bullhorn me-2"></i>Permohonan Informasi Publik (e-PPID)</h4>
                <p class="text-muted small">Layanan permohonan informasi publik resmi berdasarkan UU No. 14 Tahun 2008 tentang Keterbukaan Informasi Publik.</p>
                <hr>

                <form action="../modules/simpan_ppid.php" method="POST" enctype="multipart/form-data">
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-bold">Nama Pemohon Informasi</label>
                            <input type="text" name="nama_pemohon" class="form-control" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-bold">NIK (Nomor Induk Kependudukan)</label>
                            <input type="text" name="nik" class="form-control" maxlength="16" required>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-bold">Email</label>
                            <input type="email" name="email" class="form-control" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-bold">Nomor WhatsApp</label>
                            <input type="tel" name="no_hp" class="form-control" required>
                        </div>
                    </div>

                    <div class="mb-3">
                        <label class="form-label fw-bold">Alamat Lengkap Pemohon</label>
                        <textarea name="alamat" class="form-control" rows="2" required></textarea>
                    </div>

                    <div class="mb-3">
                        <label class="form-label fw-bold">Rincian Informasi yang Dibutuhkan</label>
                        <textarea name="rincian_informasi" class="form-control" rows="3" placeholder="Jelaskan secara spesifik dokumen/informasi yang diminta..." required></textarea>
                    </div>

                    <div class="mb-3">
                        <label class="form-label fw-bold">Tujuan Penggunaan Informasi</label>
                        <input type="text" name="tujuan_penggunaan" class="form-control" placeholder="Contoh: Riset Akademis / Pengawasan Publik" required>
                    </div>

                    <div class="mb-3">
                        <label class="form-label fw-bold">Upload Identitas Diri (KTP / SIM)</label>
                        <input type="file" name="berkas_ktp" class="form-control" accept=".jpg,.jpeg,.png,.pdf" required>
                        <small class="text-muted">Format file: JPG, PNG, PDF. Maksimal 2MB.</small>
                    </div>

                    <div class="d-grid mt-4">
                        <button type="submit" class="btn btn-primary btn-lg fs-6"><i class="fas fa-paper-plane me-2"></i>Kirim Permohonan Informasi</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>