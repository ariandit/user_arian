<?php 
require_once __DIR__ . '/../config/koneksi.php';
require_once __DIR__ . '/../includes/header.php'; 
?>

<div class="container my-5">
    <div class="row justify-content-center">
        <div class="col-md-5">
            <div class="card shadow border-0 rounded-3 p-4">
                <h4 class="fw-bold text-center text-primary mb-3">Daftar Akun Baru</h4>
                <p class="text-muted small text-center">Isi data diri untuk membuat akun pemohon layanan Bakesbangpol.</p>
                <hr>

                <?php if (isset($_SESSION['error'])): ?>
                    <div class="alert alert-danger py-2 small"><?= $_SESSION['error']; unset($_SESSION['error']); ?></div>
                <?php endif; ?>

                <form action="../modules/proses_register.php" method="POST">
                    <div class="mb-3">
                        <label class="form-label fw-bold">Nama Lengkap</label>
                        <input type="text" name="nama" class="form-control" required placeholder="Sesuai KTP">
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-bold">Nomor WhatsApp / Telp</label>
                        <input type="tel" name="no_hp" class="form-control" required placeholder="081234567890">
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-bold">Email</label>
                        <input type="email" name="email" class="form-control" required placeholder="nama@email.com">
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-bold">Password</label>
                        <input type="password" name="password" class="form-control" required placeholder="Minimal 6 Karakter">
                    </div>
                    <button type="submit" class="btn btn-primary w-100 fw-bold mt-2">Daftar & Kirim Kode Verifikasi</button>
                </form>

                <div class="text-center mt-3 small">
                    Sudah punya akun? <a href="login.php">Masuk di sini</a>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>