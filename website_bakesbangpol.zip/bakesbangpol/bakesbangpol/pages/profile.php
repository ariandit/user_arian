<?php 
require_once __DIR__ . '/../config/koneksi.php';
require_once __DIR__ . '/../includes/header.php'; 

if (!isset($_SESSION['user_logged_in']) || $_SESSION['user_logged_in'] !== true) {
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION['user_id'];
$query = mysqli_query($conn, "SELECT * FROM users WHERE id = '$user_id'");
$user = mysqli_fetch_assoc($query);
?>

<div class="container my-5">
    <div class="row justify-content-center">
        <div class="col-md-6">
            <div class="card shadow border-0 rounded-3 p-4">
                <h4 class="fw-bold text-primary mb-3"><i class="fas fa-user-cog me-2"></i>Pengaturan Profil Saya</h4>
                <hr>

                <?php if (isset($_SESSION['pesan'])): ?>
                    <div class="alert alert-success py-2 small"><?= $_SESSION['pesan']; unset($_SESSION['pesan']); ?></div>
                <?php endif; ?>

                <form action="../modules/proses_profile.php" method="POST">
                    <div class="mb-3">
                        <label class="form-label fw-bold">Nama Lengkap</label>
                        <input type="text" name="nama" class="form-control" value="<?= htmlspecialchars($user['nama']); ?>" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-bold">Email</label>
                        <input type="email" name="email" class="form-control" value="<?= htmlspecialchars($user['email']); ?>" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-bold">Nomor WhatsApp / HP</label>
                        <input type="tel" name="no_hp" class="form-control" value="<?= htmlspecialchars($user['no_hp']); ?>" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-bold">Password Baru (Opsional)</label>
                        <input type="password" name="password" class="form-control" placeholder="Kosongkan jika tidak ingin diubah">
                    </div>
                    <button type="submit" class="btn btn-primary w-100 fw-bold mt-3">Simpan Perubahan Profil</button>
                </form>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>