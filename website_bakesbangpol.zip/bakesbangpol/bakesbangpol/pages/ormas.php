<?php 
require_once __DIR__ . '/../config/koneksi.php';
require_once __DIR__ . '/../includes/header.php'; 
?>

<div class="container my-5">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card shadow-sm border-0 rounded-3 p-4">
                <h4 class="fw-bold mb-3 text-primary"><i class="fas fa-users me-2"></i>Pemberitahuan Keberadaan Ormas</h4>
                <p class="text-muted small">Pendaftaran dan pencatatan tanda bukti keberadaan Organisasi Kemasyarakatan (Ormas / LSK / Yayasan) di Kota Salatiga.</p>
                <hr>

                <form action="../modules/simpan_ormas.php" method="POST" enctype="multipart/form-data">
                    <div class="mb-3">
                        <label class="form-label fw-bold">Nama Organisasi / Ormas</label>
                        <input type="text" name="nama_ormas" class="form-control" placeholder="Contoh: Yayasan Salatiga Peduli" required>
                    </div>

                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-bold">Nama Ketua</label>
                            <input type="text" name="nama_ketua" class="form-control" placeholder="Nama Lengkap Ketua" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-bold">Bidang Kegiatan</label>
                            <input type="text" name="bidang_kegiatan" class="form-control" placeholder="Contoh: Sosial / Keagamaan / Pendidikan" required>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-bold">Email Ormas / Pengurus</label>
                            <input type="email" name="email" class="form-control" placeholder="ormas@email.com" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-bold">Nomor HP / WhatsApp Kontak</label>
                            <input type="tel" name="no_hp" class="form-control" placeholder="081234567890" required>
                        </div>
                    </div>

                    <div class="mb-3">
                        <label class="form-label fw-bold">Alamat Sekretariat di Salatiga</label>
                        <textarea name="alamat_sekretariat" class="form-control" rows="2" required></textarea>
                    </div>

                    <div class="mb-3">
                        <label class="form-label fw-bold">Berkas Persyaratan (AD/ART, SK Kemenkumham, SK Pengurus dalam 1 File PDF)</label>
                        <input type="file" name="berkas_persyaratan" class="form-control" accept=".pdf" required>
                        <small class="text-muted">Format file: PDF. Maksimal 5MB.</small>
                    </div>

                    <div class="d-grid mt-4">
                        <button type="submit" class="btn btn-primary btn-lg fs-6"><i class="fas fa-paper-plane me-2"></i>Kirim Data Ormas</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>