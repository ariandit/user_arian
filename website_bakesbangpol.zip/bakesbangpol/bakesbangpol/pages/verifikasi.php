<?php 
require_once __DIR__ . '/../config/koneksi.php';
require_once __DIR__ . '/../includes/header.php'; 

if (!isset($_SESSION['email_verifikasi'])) {
    header("Location: register.php");
    exit;
}
?>

<div class="container my-5">
    <div class="row justify-content-center">
        <div class="col-md-5">
            <div class="card shadow border-0 rounded-3 p-4 text-center">
                <i class="fas fa-envelope-open-text fa-3x text-primary mb-3"></i>
                <h4 class="fw-bold mb-2">Verifikasi Email</h4>
                <p class="text-muted small">Masukkan 6 digit kode verifikasi yang telah dikirimkan ke email: <br><strong><?= $_SESSION['email_verifikasi']; ?></strong></p>

                <?php if (isset($_SESSION['otp_simulasi'])): ?>
                    <div class="alert alert-info py-2 small mb-3">
                        <i class="fas fa-info-circle me-1"></i> Mode Pengujian Localhost Kode OTP Anda: <strong><?= $_SESSION['otp_simulasi']; ?></strong>
                    </div>
                <?php endif; ?>

                <?php if (isset($_SESSION['error'])): ?>
                    <div class="alert alert-danger py-2 small"><?= $_SESSION['error']; unset($_SESSION['error']); ?></div>
                <?php endif; ?>

                <form action="../modules/proses_verifikasi.php" method="POST">
                    <div class="mb-3">
                        <input type="text" name="otp" class="form-control form-control-lg text-center fw-bold fs-4" maxlength="6" placeholder="000000" required>
                    </div>
                    <button type="submit" class="btn btn-success w-100 fw-bold">Verifikasi & Aktifkan Akun</button>
                </form>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>