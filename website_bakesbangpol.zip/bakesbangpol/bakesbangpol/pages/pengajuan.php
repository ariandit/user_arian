<?php 
require_once __DIR__ . '/../config/koneksi.php';
require_once __DIR__ . '/../includes/header.php'; 
?>

<div class="container my-5">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card shadow-sm border-0 rounded-3 p-4">
                <h4 class="fw-bold mb-3 text-primary"><i class="fas fa-file-alt me-2"></i>Form Pengajuan Izin Penelitian / Magang</h4>
                <p class="text-muted small">Isi data diri dan unggah berkas persyaratan (Proposal/Surat Pengantar Kampus) dalam format PDF/JPG (Maks. 2MB).</p>
                <hr>

                <form action="../modules/simpan_pengajuan.php" method="POST" enctype="multipart/form-data">
                    <div class="mb-3">
                        <label class="form-label fw-bold">Jenis Layanan</label>
                        <select name="jenis_layanan" class="form-select" required>
                            <option value="Izin Penelitian">Izin Penelitian</option>
                            <option value="Izin Magang / Survey">Izin Magang / Survey</option>
                        </select>
                    </div>

                    <div class="mb-3">
                        <label class="form-label fw-bold">Nama Lengkap Pemohon</label>
                        <input type="text" name="nama_pemohon" class="form-control" placeholder="Contoh: Ahmad Budi" required>
                    </div>

                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-bold">Email</label>
                            <input type="email" name="email" class="form-control" placeholder="nama@email.com" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-bold">Nomor HP / WhatsApp</label>
                            <input type="tel" name="no_hp" class="form-control" placeholder="081234567890" required>
                        </div>
                    </div>

                    <div class="mb-3">
                        <label class="form-label fw-bold">Instansi / Universitas / Sekolah</label>
                        <input type="text" name="instansi" class="form-control" placeholder="Contoh: Universitas Diponegoro" required>
                    </div>

                    <div class="mb-3">
                        <label class="form-label fw-bold">Judul Penelitian / Magang</label>
                        <textarea name="judul_penelitian" class="form-control" rows="3" placeholder="Masukkan judul penelitian atau fokus magang..." required></textarea>
                    </div>

                    <div class="mb-3">
                        <label class="form-label fw-bold">Berkas Persyaratan (Proposal/Surat Pengantar)</label>
                        <input type="file" name="berkas_persyaratan" class="form-control" accept=".pdf,.jpg,.jpeg,.png" required>
                        <small class="text-muted">Format file yang diizinkan: PDF, JPG, PNG. Maksimal 2MB.</small>
                    </div>

                    <div class="d-grid mt-4">
                        <button type="submit" class="btn btn-primary btn-lg fs-6"><i class="fas fa-paper-plane me-2"></i>Kirim Pengajuan</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>