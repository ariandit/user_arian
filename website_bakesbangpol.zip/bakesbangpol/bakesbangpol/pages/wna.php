<?php 
require_once __DIR__ . '/../config/koneksi.php';
require_once __DIR__ . '/../includes/header.php'; 
?>

<div class="container my-5">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card shadow-sm border-0 rounded-3 p-4">
                <h4 class="fw-bold mb-3 text-primary"><i class="fas fa-passport me-2"></i>Rekomendasi Surat Keterangan Tempat Tinggal WNA</h4>
                <p class="text-muted small">Permohonan rekomendasi pendaftaran keberadaan dan Surat Keterangan Tempat Tinggal (SKTT) bagi Warga Negara Cepat/Asing.</p>
                <hr>

                <form action="../modules/simpan_wna.php" method="POST" enctype="multipart/form-data">
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-bold">Nama Lengkap WNA</label>
                            <input type="text" name="nama_wna" class="form-control" placeholder="Sesuai Paspor" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-bold">Kewarganegaraan</label>
                            <input type="text" name="kewarganegaraan" class="form-control" placeholder="Contoh: Jepang / Amerika Serikat" required>
                        </div>
                    </div>

                    <div class="mb-3">
                        <label class="form-label fw-bold">Nomor Paspor / KITAS / KITAP</label>
                        <input type="text" name="no_paspor" class="form-control" required>
                    </div>

                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-bold">Nama Penjamin / Instansi Sponsor</label>
                            <input type="text" name="nama_penjamin" class="form-control" placeholder="Sponsor / Lembaga Penjamin" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-bold">No. HP Penjamin</label>
                            <input type="tel" name="no_hp_penjamin" class="form-control" placeholder="081234567890" required>
                        </div>
                    </div>

                    <div class="mb-3">
                        <label class="form-label fw-bold">Alamat Tinggal di Kota Salatiga</label>
                        <textarea name="alamat_salatiga" class="form-control" rows="2" required></textarea>
                    </div>

                    <div class="mb-3">
                        <label class="form-label fw-bold">Tujuan Tinggal / Kegiatan</label>
                        <input type="text" name="tujuan_tinggal" class="form-control" placeholder="Contoh: Studi / Bekerja / Rohani" required>
                    </div>

                    <div class="mb-3">
                        <label class="form-label fw-bold">Upload Paspor & KITAS/KITAP (Gabung 1 PDF / Gambar)</label>
                        <input type="file" name="berkas_persyaratan" class="form-control" accept=".pdf,.jpg,.jpeg,.png" required>
                        <small class="text-muted">Format file: PDF, JPG, PNG. Maksimal 2MB.</small>
                    </div>

                    <div class="d-grid mt-4">
                        <button type="submit" class="btn btn-primary btn-lg fs-6"><i class="fas fa-paper-plane me-2"></i>Kirim Pengajuan SKTT</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>