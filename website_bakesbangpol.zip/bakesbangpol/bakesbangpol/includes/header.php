<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Deteksi otomatis Base URL agar link tidak pernah 404 di folder manapun
$protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? "https://" : "http://";
$domain   = $_SERVER['HTTP_HOST'];
$doc_root = str_replace('\\', '/', $_SERVER['DOCUMENT_ROOT']);
$dir      = str_replace('\\', '/', __DIR__);
$rel_dir  = str_replace($doc_root, '', dirname($dir));
$base_url = rtrim($protocol . $domain . $rel_dir, '/') . '/';
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bakesbangpol Kota Salatiga</title>
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <style>
        :root {
            --primary-color: #0d3b66;
            --accent-color: #f4d35e;
        }
        .bg-primary-custom { background-color: var(--primary-color); }
        .btn-primary-custom { background-color: var(--primary-color); color: #fff; }
        .btn-primary-custom:hover { background-color: #092847; color: #fff; }
        .hero-section {
            background: linear-gradient(rgba(13, 59, 102, 0.85), rgba(13, 59, 102, 0.85)), url('https://images.unsplash.com/photo-1577495508048-b635879837f1?auto=format&fit=crop&w=1200&q=80') center/cover;
            color: white;
            padding: 80px 0;
        }
        .card-service { transition: transform 0.2s; border: none; }
        .card-service:hover { transform: translateY(-5px); }
        .logo-circle {
            width: 60px;
            height: 60px;
            border-radius: 50%;
            object-fit: contain;  
            background: white;
            display: block;
        }
    </style>
</head>
<body>

<!-- Navigation Bar -->
<nav class="navbar navbar-expand-lg navbar-dark bg-primary-custom sticky-top shadow-sm">
    <div class="container">
        <a class="navbar-brand d-flex align-items-center gap-2" href="<?= $base_url; ?>index.php">
            <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQQott_j6OX0DGEpqC8RwKraL5lMlqVOpgzCbMwjeh_NZBbW0NBjr6AKEyB&s=10" alt="Logo Salatiga" class="logo-circle">
            <div>
                <strong class="d-block leading-none">BAKESBANGPOL</strong>
                <small style="font-size: 0.75rem;">KOTA SALATIGA</small>
            </div>
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto align-items-lg-center">
                <li class="nav-item"><a class="nav-link active" href="<?= $base_url; ?>index.php">Beranda</a></li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" data-bs-toggle="dropdown">Profil</a>
                    <ul class="dropdown-menu">
                        <li><a class="dropdown-item" href="https://bakesbangpol.salatiga.go.id/visi-dan-misi/" target="_blank">Visi & Misi</a></li>
                        <li><a class="dropdown-item" href="https://bakesbangpol.salatiga.go.id/struktur-organisasi/" target="_blank">Struktur Organisasi</a></li>
                    </ul>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" data-bs-toggle="dropdown">Layanan Online</a>
                    <ul class="dropdown-menu">
                        <li><a class="dropdown-item" href="<?= $base_url; ?>index.php#layanan">Izin Penelitian / Magang</a></li>
                        <li><a class="dropdown-item" href="#">Pendaftaran Ormas</a></li>
                        <li><a class="dropdown-item" href="#">Surat Keterangan Parpol</a></li>
                    </ul>
                </li>
                <li class="nav-item"><a class="nav-link" href="#">PPID</a></li>
                <li class="nav-item me-lg-2"><a class="nav-link" href="#">Kontak</a></li>
                
                <li class="nav-item">
                    <div class="d-flex align-items-center gap-2 mt-2 mt-lg-0">
                        <?php if (isset($_SESSION['admin_logged_in']) && $_SESSION['admin_logged_in'] === true): ?>
                            <a href="<?= $base_url; ?>admin/index.php" class="btn btn-outline-light btn-sm"><i class="fas fa-user-shield me-1"></i> Dashboard Admin</a>
                            <a href="<?= $base_url; ?>logout.php" class="btn btn-danger btn-sm" title="Keluar"><i class="fas fa-sign-out-alt"></i></a>
                        
                        <?php elseif (isset($_SESSION['user_logged_in']) && $_SESSION['user_logged_in'] === true): ?>
                            <a href="<?= $base_url; ?>pages/profile.php" class="btn btn-outline-light btn-sm"><i class="fas fa-file-invoice me-1"></i> Berkas Saya (<?= htmlspecialchars($_SESSION['user_nama']); ?>)</a>
                            <a href="<?= $base_url; ?>logout.php" class="btn btn-danger btn-sm" title="Keluar"><i class="fas fa-sign-out-alt"></i></a>
                        
                        <?php else: ?>
                            <a href="<?= $base_url; ?>pages/login.php" class="btn btn-outline-light btn-sm"><i class="fas fa-sign-in-alt me-1"></i> Masuk</a>
                            <a href="<?= $base_url; ?>pages/register.php" class="btn btn-primary btn-sm"><i class="fas fa-user-plus me-1"></i> Daftar</a>
                        <?php endif; ?>
                    </div>
                </li>
            </ul>
        </div>
    </div>
</nav>