<?php 
require_once __DIR__ . '/config/koneksi.php';
require_once __DIR__ . '/includes/header.php'; 
?>

<!-- Hero Section -->
<section class="hero-section text-center">
    <div class="container">
        <h1 class="fw-bold display-5">Pelayanan Publik Transparan & Modern</h1>
        <p class="lead">Badan Kesatuan Bangsa dan Politik Kota Salatiga</p>
    </div>
</section>

<!-- Widget Tracking Resi Interaktif -->
<div class="container position-relative" style="margin-top: -40px; z-index: 10;">
    <div class="row justify-content-center">
        <div class="col-md-9 col-lg-8">
            <div class="card shadow-lg border-0 rounded-3 p-4 bg-white">
                <h5 class="text-center fw-bold mb-3 text-dark">
                    <i class="fas fa-search me-2 text-primary"></i>Lacak Status Permohonan Berkas
                </h5>
                <form id="formTracking">
                    <div class="input-group input-group-lg">
                        <input type="text" id="kode_tiket" class="form-control fs-6" placeholder="Masukkan Nomor Tiket (Contoh: PEN-202609-XXXX)" required>
                        <button class="btn btn-primary-custom fs-6 px-4" type="submit" id="btnCek">
                            <i class="fas fa-paper-plane me-1"></i> Cek Status
                        </button>
                    </div>
                </form>
                <div id="hasilTracking" class="mt-3" style="display: none;"></div>
            </div>
        </div>
    </div>
</div>

<!-- Layanan Utama -->
<section class="container my-5 py-3">
    <div class="text-center mb-5">
        <h3 class="fw-bold">Layanan Digital</h3>
        <p class="text-muted">Akses cepat layanan rekomendasi dan perizinan online</p>
    </div>
    <div class="row g-4">
        <div class="col-md-3">
            <div class="card card-service shadow-sm text-center p-4 h-100 bg-light">
                <div class="fs-1 text-primary mb-3"><i class="fas fa-file-signature"></i></div>
                <h6 class="fw-bold">Izin Penelitian / Magang</h6>
                <p class="small text-muted">Pengajuan surat rekomendasi secara mandiri.</p>
                <a href="pages/pengajuan.php" class="btn btn-sm btn-outline-primary mt-auto">Ajukan Sekarang</a>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card card-service shadow-sm text-center p-4 h-100 bg-light">
                <div class="fs-1 text-primary mb-3"><i class="fas fa-users"></i></div>
                <h6 class="fw-bold">Pemberitahuan Ormas</h6>
                <p class="small text-muted">Pendataan dan tanda bukti keberadaan Ormas.</p>
                <a href="pages/ormas.php" class="btn btn-sm btn-outline-primary mt-auto">Daftar Ormas</a>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card card-service shadow-sm text-center p-4 h-100 bg-light">
                <div class="fs-1 text-primary mb-3"><i class="fas fa-passport"></i></div>
                <h6 class="fw-bold">Surat Keterangan WNA</h6>
                <p class="small text-muted">Layanan administrasi tempat tinggal WNA.</p>
                <a href="pages/wna.php" class="btn btn-sm btn-outline-primary mt-auto">Ajukan SKTT</a>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card card-service shadow-sm text-center p-4 h-100 bg-light">
                <div class="fs-1 text-primary mb-3"><i class="fas fa-bullhorn"></i></div>
                <h6 class="fw-bold">Permohonan e-PPID</h6>
                <p class="small text-muted">Permohonan informasi publik transparan.</p>
                <a href="pages/ppid.php" class="btn btn-sm btn-outline-primary mt-auto">Akses Informasi</a>
            </div>
        </div>
    </div>
</section>

<script>
document.getElementById('formTracking').addEventListener('submit', function(e) {
    e.preventDefault();
    const kode = document.getElementById('kode_tiket').value.trim();
    const hasilDiv = document.getElementById('hasilTracking');
    const btnCek = document.getElementById('btnCek');
    
    hasilDiv.style.display = 'block';
    hasilDiv.innerHTML = '<div class="alert alert-info py-2 text-center mb-0"><i class="fas fa-spinner fa-spin me-2"></i>Mencari data permohonan...</div>';
    btnCek.disabled = true;

    fetch(`api/track.php?kode=${encodeURIComponent(kode)}`)
        .then(response => response.json())
        .then(data => {
            btnCek.disabled = false;
            if (data.status === 'success') {
                hasilDiv.innerHTML = `
                    <div class="alert alert-success border-0 shadow-sm mb-0">
                        <div class="d-flex justify-content-between align-items-center mb-2">
                            <h6 class="fw-bold mb-0">${data.nama}</h6>
                            <span class="badge bg-primary">${data.posisi_berkas}</span>
                        </div>
                        <p class="small mb-1"><strong>Jenis Layanan:</strong> ${data.layanan}</p>
                        <p class="small mb-0 text-muted"><strong>Tanggal Pengajuan:</strong> ${data.tanggal}</p>
                    </div>
                `;
            } else {
                hasilDiv.innerHTML = `<div class="alert alert-danger py-2 text-center mb-0"><i class="fas fa-exclamation-circle me-1"></i>${data.message}</div>`;
            }
        })
        .catch(() => {
            btnCek.disabled = false;
            hasilDiv.innerHTML = '<div class="alert alert-danger py-2 text-center mb-0"><i class="fas fa-wifi me-1"></i>Gagal terhubung ke server.</div>';
        });
});
</script>

<?php require_once __DIR__ . '/includes/footer.php'; ?>