<?php
session_start();
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header("Location: login.php");
    exit;
}

require_once __DIR__ . '/../config/koneksi.php';
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Admin - CRUD Permohonan</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
</head>
<body class="bg-light">

<!-- Navbar Admin -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark sticky-top shadow">
    <div class="container-fluid">
        <a class="navbar-brand fw-bold" href="index.php"><i class="fas fa-user-shield me-2"></i>Panel Admin Bakesbangpol</a>
        <div class="d-flex align-items-center text-white">
            <span class="me-3"><i class="fas fa-user-circle me-1"></i> <?= $_SESSION['admin_nama']; ?></span>
            <a href="logout.php" class="btn btn-sm btn-danger"><i class="fas fa-sign-out-alt me-1"></i>Keluar</a>
        </div>
    </div>
</nav>

<div class="container-fluid py-4">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h4 class="fw-bold"><i class="fas fa-folder-open me-2 text-primary"></i>Kelola Permohonan Penelitian & Magang</h4>
        <button class="btn btn-success" data-bs-toggle="modal" data-bs-target="#modalTambah">
            <i class="fas fa-plus-circle me-1"></i> Tambah Permohonan Manual
        </button>
    </div>

    <!-- Alert Notifikasi -->
    <?php if (isset($_SESSION['pesan'])): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <i class="fas fa-check-circle me-1"></i> <?= $_SESSION['pesan']; unset($_SESSION['pesan']); ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <?php if (isset($_SESSION['error'])): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <i class="fas fa-exclamation-triangle me-1"></i> <?= $_SESSION['error']; unset($_SESSION['error']); ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <div class="card border-0 shadow-sm">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-hover table-bordered align-middle">
                    <thead class="table-dark">
                        <tr>
                            <th width="50">No</th>
                            <th>No. Tiket</th>
                            <th>Pemohon / Kontak</th>
                            <th>Instansi</th>
                            <th>Layanan & Judul</th>
                            <th>Status</th>
                            <th>Berkas</th>
                            <th width="140" class="text-center">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $query = "SELECT * FROM permohonan ORDER BY id DESC";
                        $result = mysqli_query($conn, $query);
                        $no = 1;

                        if (mysqli_num_rows($result) > 0) {
                            while ($row = mysqli_fetch_assoc($result)) {
                                // Warna Badge Status
                                $badgeColor = 'bg-warning text-dark';
                                if ($row['status'] === 'Disetujui') $badgeColor = 'bg-primary';
                                if ($row['status'] === 'Selesai') $badgeColor = 'bg-success';
                                if ($row['status'] === 'Ditolak') $badgeColor = 'bg-danger';
                                ?>
                                <tr>
                                    <td><?= $no++; ?></td>
                                    <td><span class="badge bg-secondary"><?= $row['nomor_tiket']; ?></span></td>
                                    <td>
                                        <strong><?= htmlspecialchars($row['nama_pemohon']); ?></strong><br>
                                        <small class="text-muted"><i class="fas fa-envelope"></i> <?= htmlspecialchars($row['email']); ?></small><br>
                                        <small class="text-muted"><i class="fas fa-phone"></i> <?= htmlspecialchars($row['no_hp']); ?></small>
                                    </td>
                                    <td><?= htmlspecialchars($row['instansi']); ?></td>
                                    <td>
                                        <span class="fw-bold text-primary"><?= $row['jenis_layanan']; ?></span>
                                        <p class="small text-muted mb-0"><?= htmlspecialchars($row['judul_penelitian']); ?></p>
                                    </td>
                                    <td><span class="badge <?= $badgeColor; ?>"><?= $row['status']; ?></span></td>
                                    <td class="text-center">
                                        <a href="../uploads/<?= $row['berkas_persyaratan']; ?>" target="_blank" class="btn btn-sm btn-outline-primary">
                                            <i class="fas fa-file-download"></i> Unduh
                                        </a>
                                    </td>
                                    <td class="text-center">
                                        <button class="btn btn-sm btn-warning mb-1 btn-edit" 
                                                data-id="<?= $row['id']; ?>"
                                                data-nama="<?= htmlspecialchars($row['nama_pemohon']); ?>"
                                                data-email="<?= htmlspecialchars($row['email']); ?>"
                                                data-hp="<?= htmlspecialchars($row['no_hp']); ?>"
                                                data-instansi="<?= htmlspecialchars($row['instansi']); ?>"
                                                data-judul="<?= htmlspecialchars($row['judul_penelitian']); ?>"
                                                data-layanan="<?= $row['jenis_layanan']; ?>"
                                                data-status="<?= $row['status']; ?>"
                                                data-bs-toggle="modal" data-bs-target="#modalEdit">
                                            <i class="fas fa-edit"></i> Edit
                                        </button>
                                        <a href="proses_crud.php?aksi=hapus&id=<?= $row['id']; ?>" class="btn btn-sm btn-danger mb-1" onclick="return confirm('Apakah Anda yakin ingin menghapus data dan berkas ini?')">
                                            <i class="fas fa-trash-alt"></i> Hapus
                                        </a>
                                    </td>
                                </tr>
                                <?php
                            }
                        } else {
                            echo "<tr><td colspan='8' class='text-center text-muted'>Belum ada data permohonan.</td></tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- ========================================================================= -->
<!-- MODAL TAMBAH DATA (CREATE) -->
<!-- ========================================================================= -->
<div class="modal fade" id="modalTambah" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <form action="proses_crud.php" method="POST" enctype="multipart/form-data">
                <input type="hidden" name="aksi" value="tambah">
                <div class="modal-header bg-success text-white">
                    <h5 class="modal-title"><i class="fas fa-plus-circle me-2"></i>Tambah Permohonan Baru</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-bold">Jenis Layanan</label>
                            <select name="jenis_layanan" class="form-select" required>
                                <option value="Izin Penelitian">Izin Penelitian</option>
                                <option value="Izin Magang / Survey">Izin Magang / Survey</option>
                            </select>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-bold">Status Awal</label>
                            <select name="status" class="form-select" required>
                                <option value="Sedang Diverifikasi">Sedang Diverifikasi</option>
                                <option value="Disetujui">Disetujui</option>
                                <option value="Selesai">Selesai</option>
                                <option value="Ditolak">Ditolak</option>
                            </select>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-bold">Nama Pemohon</label>
                        <input type="text" name="nama_pemohon" class="form-control" required>
                    </div>
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-bold">Email</label>
                            <input type="email" name="email" class="form-control" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-bold">No. HP / WA</label>
                            <input type="tel" name="no_hp" class="form-control" required>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-bold">Instansi / Kampus</label>
                        <input type="text" name="instansi" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-bold">Judul Penelitian / Magang</label>
                        <textarea name="judul_penelitian" class="form-control" rows="2" required></textarea>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-bold">Upload Berkas Persyaratan (PDF/JPG)</label>
                        <input type="file" name="berkas_persyaratan" class="form-control" accept=".pdf,.jpg,.jpeg,.png" required>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-success">Simpan Data</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- ========================================================================= -->
<!-- MODAL EDIT DATA (UPDATE) -->
<!-- ========================================================================= -->
<div class="modal fade" id="modalEdit" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <form action="proses_crud.php" method="POST">
                <input type="hidden" name="aksi" value="edit">
                <input type="hidden" name="id" id="edit_id">
                <div class="modal-header bg-warning text-dark">
                    <h5 class="modal-title"><i class="fas fa-edit me-2"></i>Edit Permohonan & Status</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-bold">Status Permohonan</label>
                            <select name="status" id="edit_status" class="form-select" required>
                                <option value="Sedang Diverifikasi">Sedang Diverifikasi</option>
                                <option value="Disetujui">Disetujui</option>
                                <option value="Selesai">Selesai</option>
                                <option value="Ditolak">Ditolak</option>
                            </select>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-bold">Jenis Layanan</label>
                            <select name="jenis_layanan" id="edit_layanan" class="form-select" required>
                                <option value="Izin Penelitian">Izin Penelitian</option>
                                <option value="Izin Magang / Survey">Izin Magang / Survey</option>
                            </select>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-bold">Nama Pemohon</label>
                        <input type="text" name="nama_pemohon" id="edit_nama" class="form-control" required>
                    </div>
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-bold">Email</label>
                            <input type="email" name="email" id="edit_email" class="form-control" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-bold">No. HP / WA</label>
                            <input type="tel" name="no_hp" id="edit_hp" class="form-control" required>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-bold">Instansi / Kampus</label>
                        <input type="text" name="instansi" id="edit_instansi" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-bold">Judul Penelitian / Magang</label>
                        <textarea name="judul_penelitian" id="edit_judul" class="form-control" rows="2" required></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
// JavaScript untuk mengisi data ke Modal Edit secara otomatis saat tombol Edit diklik
document.querySelectorAll('.btn-edit').forEach(button => {
    button.addEventListener('click', function() {
        document.getElementById('edit_id').value = this.dataset.id;
        document.getElementById('edit_nama').value = this.dataset.nama;
        document.getElementById('edit_email').value = this.dataset.email;
        document.getElementById('edit_hp').value = this.dataset.hp;
        document.getElementById('edit_instansi').value = this.dataset.instansi;
        document.getElementById('edit_judul').value = this.dataset.judul;
        document.getElementById('edit_layanan').value = this.dataset.layanan;
        document.getElementById('edit_status').value = this.dataset.status;
    });
});
</script>

</body>
</html>