<?php
session_start();
require_once __DIR__ . '/../config/koneksi.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);

    // Cek username di database
    $stmt = mysqli_prepare($conn, "SELECT id, password, nama_lengkap FROM admin_users WHERE username = ?");
    mysqli_stmt_bind_param($stmt, "s", $username);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    if ($row = mysqli_fetch_assoc($result)) {
        // Verifikasi password yang dienkripsi (Bcrypt)
        if (password_verify($password, $row['password'])) {
            // Login Berhasil, set Session
            $_SESSION['admin_logged_in'] = true;
            $_SESSION['admin_id'] = $row['id'];
            $_SESSION['admin_nama'] = $row['nama_lengkap'];
            
            header("Location: index.php"); // Arahkan ke Dashboard
            exit;
        } else {
            $_SESSION['error'] = "Password yang Anda masukkan salah!";
            header("Location: login.php");
            exit;
        }
    } else {
        $_SESSION['error'] = "Username tidak ditemukan!";
        header("Location: login.php");
        exit;
    }
} else {
    header("Location: login.php");
    exit;
}
?>