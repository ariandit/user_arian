<?php
session_start();
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header("Location: login.php");
    exit;
}

require_once __DIR__ . '/../config/koneksi.php';

$aksi = isset($_REQUEST['aksi']) ? $_REQUEST['aksi'] : '';

// ------------------------------------------------------------------
// 1. TAMBAH DATA (CREATE)
// ------------------------------------------------------------------
if ($aksi === 'tambah') {
    $nama_pemohon    = trim($_POST['nama_pemohon']);
    $email           = trim($_POST['email']);
    $no_hp           = trim($_POST['no_hp']);
    $instansi        = trim($_POST['instansi']);
    $judul_penelitian= trim($_POST['judul_penelitian']);
    $jenis_layanan   = trim($_POST['jenis_layanan']);
    $status          = trim($_POST['status']);

    $prefix = ($jenis_layanan === 'Izin Penelitian') ? 'PEN' : 'MGN';
    $nomor_tiket = $prefix . '-' . date('Ym') . '-' . strtoupper(substr(md5(uniqid(rand(), true)), 0, 4));

    $file = $_FILES['berkas_persyaratan'];
    $fileExt = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    $newFileName = 'BERKAS_' . $nomor_tiket . '.' . $fileExt;
    $uploadDir   = __DIR__ . '/../uploads/';

    if (move_uploaded_file($file['tmp_name'], $uploadDir . $newFileName)) {
        $stmt = mysqli_prepare($conn, "INSERT INTO permohonan (nomor_tiket, nama_pemohon, email, no_hp, instansi, judul_penelitian, jenis_layanan, status, berkas_persyaratan) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
        mysqli_stmt_bind_param($stmt, "sssssssss", $nomor_tiket, $nama_pemohon, $email, $no_hp, $instansi, $judul_penelitian, $jenis_layanan, $status, $newFileName);
        
        if (mysqli_stmt_execute($stmt)) {
            $_SESSION['pesan'] = "Data berhasil ditambahkan dengan Nomor Tiket: " . $nomor_tiket;
        } else {
            $_SESSION['error'] = "Gagal menyimpan data ke database.";
        }
        mysqli_stmt_close($stmt);
    } else {
        $_SESSION['error'] = "Gagal mengunggah berkas.";
    }
    header("Location: index.php");
    exit;
}

// ------------------------------------------------------------------
// 2. UBAH / EDIT DATA (UPDATE)
// ------------------------------------------------------------------
if ($aksi === 'edit') {
    $id              = intval($_POST['id']);
    $nama_pemohon    = trim($_POST['nama_pemohon']);
    $email           = trim($_POST['email']);
    $no_hp           = trim($_POST['no_hp']);
    $instansi        = trim($_POST['instansi']);
    $judul_penelitian= trim($_POST['judul_penelitian']);
    $jenis_layanan   = trim($_POST['jenis_layanan']);
    $status          = trim($_POST['status']);

    $stmt = mysqli_prepare($conn, "UPDATE permohonan SET nama_pemohon = ?, email = ?, no_hp = ?, instansi = ?, judul_penelitian = ?, jenis_layanan = ?, status = ? WHERE id = ?");
    mysqli_stmt_bind_param($stmt, "sssssssi", $nama_pemohon, $email, $no_hp, $instansi, $judul_penelitian, $jenis_layanan, $status, $id);

    if (mysqli_stmt_execute($stmt)) {
        $_SESSION['pesan'] = "Data permohonan berhasil diperbarui!";
    } else {
        $_SESSION['error'] = "Gagal memperbarui data.";
    }
    mysqli_stmt_close($stmt);
    header("Location: index.php");
    exit;
}

// ------------------------------------------------------------------
// 3. HAPUS DATA (DELETE)
// ------------------------------------------------------------------
if ($aksi === 'hapus') {
    $id = intval($_GET['id']);

    // Cari nama file berkas untuk dihapus dari folder uploads
    $stmt_file = mysqli_prepare($conn, "SELECT berkas_persyaratan FROM permohonan WHERE id = ?");
    mysqli_stmt_bind_param($stmt_file, "i", $id);
    mysqli_stmt_execute($stmt_file);
    $res = mysqli_stmt_get_result($stmt_file);

    if ($row = mysqli_fetch_assoc($res)) {
        $filePath = __DIR__ . '/../uploads/' . $row['berkas_persyaratan'];
        if (file_exists($filePath) && !empty($row['berkas_persyaratan'])) {
            unlink($filePath); // Hapus file fisik dari folder
        }
    }
    mysqli_stmt_close($stmt_file);

    // Hapus data dari database
    $stmt = mysqli_prepare($conn, "DELETE FROM permohonan WHERE id = ?");
    mysqli_stmt_bind_param($stmt, "i", $id);

    if (mysqli_stmt_execute($stmt)) {
        $_SESSION['pesan'] = "Data dan berkas berhasil dihapus!";
    } else {
        $_SESSION['error'] = "Gagal menghapus data.";
    }
    mysqli_stmt_close($stmt);
    header("Location: index.php");
    exit;
}

mysqli_close($conn);
?>