<?php
require_once __DIR__ . '/../config/koneksi.php';

$username = 'admin';
$password_baru = 'password123';

// Membuat enkripsi password yang 100% cocok dengan sistem PHP Anda
$hashed_password = password_hash($password_baru, PASSWORD_DEFAULT);
$nama_lengkap = 'Administrator Kesbangpol';

// Cek apakah akun admin sudah ada di database
$cek_user = mysqli_query($conn, "SELECT id FROM admin_users WHERE username = '$username'");

if (mysqli_num_rows($cek_user) > 0) {
    // Jika akun sudah ada, kita perbarui passwordnya saja
    $query = "UPDATE admin_users SET password = '$hashed_password' WHERE username = '$username'";
    $pesan = "Berhasil! Password admin telah direset.";
} else {
    // Jika akun belum ada, kita buatkan baru
    $query = "INSERT INTO admin_users (username, password, nama_lengkap) VALUES ('$username', '$hashed_password', '$nama_lengkap')";
    $pesan = "Berhasil! Akun admin baru telah dibuat.";
}

if (mysqli_query($conn, $query)) {
    echo "<h3>$pesan</h3>";
    echo "<p>Silakan gunakan kredensial berikut untuk login:</p>";
    echo "<ul>";
    echo "<li>Username: <b>" . $username . "</b></li>";
    echo "<li>Password: <b>" . $password_baru . "</b></li>";
    echo "</ul>";
    echo "<a href='login.php'>Klik di sini untuk menuju halaman Login</a>";
} else {
    echo "Terjadi kesalahan: " . mysqli_error($conn);
}
?>