<?php
session_start();
// Jika sudah login, langsung arahkan ke dashboard admin
if (isset($_SESSION['admin_logged_in']) && $_SESSION['admin_logged_in'] === true) {
    header("Location: index.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Admin - Bakesbangpol Salatiga</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <style>
        body { background-color: #f4f6f9; }
        .login-card { max-width: 400px; margin: 100px auto; border-radius: 12px; box-shadow: 0 4px 15px rgba(0,0,0,0.1); }
    </style>
</head>
<body>
    <div class="container">
        <div class="card login-card p-4 border-0 bg-white">
            <div class="text-center mb-4">
                <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQQott_j6OX0DGEpqC8RwKraL5lMlqVOpgzCbMwjeh_NZBbW0NBjr6AKEyB&s=10" alt="Logo Salatiga" class="logo-circle">
            <style>
.logo-circle {
  width: 60px;
  height: 60px;
  border-radius: 50%;
  object-fit: contain;
  position: static;
  background: white;
    display: flex;
    justify-content: center;
    align-items: center;
}
</style>
                <h4 class="fw-bold mt-2 text-primary">Login Admin</h4>
                <p class="text-muted small">Panel Pengelolaan Layanan Kesbangpol</p>
            </div>

            <?php if(isset($_SESSION['error'])): ?>
                <div class="alert alert-danger py-2 small">
                    <?php echo $_SESSION['error']; unset($_SESSION['error']); ?>
                </div>
            <?php endif; ?>

            <form action="auth.php" method="POST">
                <div class="mb-3">
                    <label class="form-label fw-bold small">Username</label>
                    <div class="input-group">
                        <span class="input-group-text"><i class="fas fa-user"></i></span>
                        <input type="text" name="username" class="form-control" required placeholder="Masukkan username">
                    </div>
                </div>
                <div class="mb-4">
                    <label class="form-label fw-bold small">Password</label>
                    <div class="input-group">
                        <span class="input-group-text"><i class="fas fa-lock"></i></span>
                        <input type="password" name="password" class="form-control" required placeholder="Masukkan password">
                    </div>
                </div>
                <button type="submit" class="btn btn-primary w-100 fw-bold">Masuk</button>
            </form>
            <div class="text-center mt-3">
                <a href="../index.php" class="text-decoration-none small text-muted"><i class="fas fa-arrow-left me-1"></i>Kembali ke Halaman Publik</a>
            </div>
        </div>
    </div>
</body>
</html>