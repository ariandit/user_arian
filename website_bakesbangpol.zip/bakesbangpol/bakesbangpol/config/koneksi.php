<?php
$host = "localhost";
$user = "root";
$pass = "";
$db   = "db_bakesbangpol";

$conn = mysqli_connect($host, $user, $pass, $db);

if (!$conn) {
    die("Koneksi Database Gagal: " . mysqli_connect_error());
}

// Deteksi Otomatis Root URL Project
$protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https://" : "http://";
$host = $_SERVER['HTTP_HOST'];
$doc_root = str_replace('\\', '/', $_SERVER['DOCUMENT_ROOT']);
$dir_root = str_replace('\\', '/', dirname(__DIR__));
$folder_name = str_replace($doc_root, '', $dir_root);

define('BASE_URL', $protocol . $host . $folder_name . '/');
?>