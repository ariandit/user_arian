<?php
error_reporting(0);
ini_set('display_errors', 0);
header('Content-Type: application/json; charset=utf-8');

require_once __DIR__ . '/../config/koneksi.php';

$kode = isset($_GET['kode']) ? trim($_GET['kode']) : '';

if (empty($kode)) {
    echo json_encode(['status' => 'error', 'message' => 'Masukkan nomor tiket permohonan.']);
    exit;
}

// Menentukan tabel berdasarkan prefix nomor tiket
$prefix = strtoupper(substr($kode, 0, 3));

if ($prefix === 'ORM') {
    $sql = "SELECT nama_ormas AS nama, 'Pemberitahuan Keberadaan Ormas' AS layanan, status, created_at FROM ormas WHERE nomor_tiket = ?";
} else if ($prefix === 'WNA') {
    $sql = "SELECT nama_wna AS nama, 'Surat Keterangan Tempat Tinggal WNA' AS layanan, status, created_at FROM layanan_wna WHERE nomor_tiket = ?";
} else if ($prefix === 'PPD') {
    $sql = "SELECT nama_pemohon AS nama, 'Permohonan Informasi (e-PPID)' AS layanan, status, created_at FROM permohonan_ppid WHERE nomor_tiket = ?";
} else {
    // Default: Tabel permohonan (Penelitian / Magang)
    $sql = "SELECT nama_pemohon AS nama, jenis_layanan AS layanan, status, created_at FROM permohonan WHERE nomor_tiket = ?";
}

$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "s", $kode);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

if ($row = mysqli_fetch_assoc($result)) {
    echo json_encode([
        'status' => 'success',
        'nama' => htmlspecialchars($row['nama']),
        'layanan' => htmlspecialchars($row['layanan']),
        'posisi_berkas' => htmlspecialchars($row['status']),
        'tanggal' => date('d-m-Y H:i', strtotime($row['created_at']))
    ]);
} else {
    echo json_encode(['status' => 'error', 'message' => 'Nomor tiket tidak ditemukan dalam sistem.']);
}

mysqli_stmt_close($stmt);
mysqli_close($conn);
?>