<?php
require_once __DIR__ . '/../config/koneksi.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nama_ormas   = trim($_POST['nama_ormas']);
    $nama_ketua   = trim($_POST['nama_ketua']);
    $email        = trim($_POST['email']);
    $no_hp        = trim($_POST['no_hp']);
    $alamat       = trim($_POST['alamat_sekretariat']);
    $bidang       = trim($_POST['bidang_kegiatan']);

    $nomor_tiket  = 'ORM-' . date('Ym') . '-' . strtoupper(substr(md5(uniqid(rand(), true)), 0, 4));

    $file     = $_FILES['berkas_persyaratan'];
    $fileExt  = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));

    if ($fileExt !== 'pdf') {
        die("<script>alert('Persyaratan Ormas wajib berformat PDF!'); window.history.back();</script>");
    }

    $newFileName = 'ORMAS_' . $nomor_tiket . '.' . $fileExt;
    $uploadDir   = __DIR__ . '/../uploads/';

    if (move_uploaded_file($file['tmp_name'], $uploadDir . $newFileName)) {
        $stmt = mysqli_prepare($conn, "INSERT INTO ormas (nomor_tiket, nama_ormas, nama_ketua, no_hp, email, alamat_sekretariat, bidang_kegiatan, berkas_persyaratan) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
        mysqli_stmt_bind_param($stmt, "ssssssss", $nomor_tiket, $nama_ormas, $nama_ketua, $no_hp, $email, $alamat, $bidang, $newFileName);

        if (mysqli_stmt_execute($stmt)) {
            echo "<script>alert('Pendaftaran Ormas Berhasil!\\n\\nNomor Tiket Anda: " . $nomor_tiket . "'); window.location.href = '../index.php';</script>";
        } else {
            echo "<script>alert('Gagal menyimpan ke database.'); window.history.back();</script>";
        }
        mysqli_stmt_close($stmt);
    }
}
mysqli_close($conn);
?>