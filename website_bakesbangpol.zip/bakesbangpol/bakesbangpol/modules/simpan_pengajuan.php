<?php
require_once __DIR__ . '/../config/koneksi.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nama_pemohon    = trim($_POST['nama_pemohon']);
    $email           = trim($_POST['email']);
    $no_hp           = trim($_POST['no_hp']);
    $instansi        = trim($_POST['instansi']);
    $judul_penelitian= trim($_POST['judul_penelitian']);
    $jenis_layanan   = trim($_POST['jenis_layanan']);

    $prefix = ($jenis_layanan === 'Izin Penelitian') ? 'PEN' : 'MGN';
    $nomor_tiket = $prefix . '-' . date('Ym') . '-' . strtoupper(substr(md5(uniqid(rand(), true)), 0, 4));

    $file = $_FILES['berkas_persyaratan'];
    $fileName = $file['name'];
    $fileTmp  = $file['tmp_name'];
    $fileSize = $file['size'];
    $fileErr  = $file['error'];

    $extAllowed = ['pdf', 'jpg', 'jpeg', 'png'];
    $fileExt = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));

    if (!in_array($fileExt, $extAllowed)) {
        die("<script>alert('Format file tidak diizinkan! Gunakan PDF, JPG, atau PNG.'); window.history.back();</script>");
    }

    if ($fileSize > 2097152) {
        die("<script>alert('Ukuran file terlalu besar! Maksimal 2MB.'); window.history.back();</script>");
    }

    if ($fileErr !== 0) {
        die("<script>alert('Terjadi kesalahan saat mengunggah file.'); window.history.back();</script>");
    }

    $newFileName = 'BERKAS_' . $nomor_tiket . '.' . $fileExt;
    $uploadDir   = __DIR__ . '/../uploads/';

    if (!is_dir($uploadDir)) {
        mkdir($uploadDir, 0755, true);
    }

    $destPath = $uploadDir . $newFileName;

    if (move_uploaded_file($fileTmp, $destPath)) {
        $stmt = mysqli_prepare($conn, "INSERT INTO permohonan (nomor_tiket, nama_pemohon, email, no_hp, instansi, judul_penelitian, jenis_layanan, berkas_persyaratan) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
        mysqli_stmt_bind_param($stmt, "ssssssss", $nomor_tiket, $nama_pemohon, $email, $no_hp, $instansi, $judul_penelitian, $jenis_layanan, $newFileName);

        if (mysqli_stmt_execute($stmt)) {
            echo "<script>
                alert('Pengajuan Berhasil Ditambahkan!\\n\\nNomor Tiket Anda: " . $nomor_tiket . "\\nSimpan nomor tiket ini untuk cek status permohonan.');
                window.location.href = '../index.php';
            </script>";
        } else {
            echo "<script>alert('Gagal menyimpan data ke database.'); window.history.back();</script>";
        }
        mysqli_stmt_close($stmt);
    } else {
        echo "<script>alert('Gagal memindahkan file ke folder uploads.'); window.history.back();</script>";
    }
}
mysqli_close($conn);
?>