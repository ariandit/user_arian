<?php
session_start();
require_once __DIR__ . '/../config/koneksi.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $input    = trim($_POST['login_input']);
    $password = trim($_POST['password']);

    // 1. Cek Login sebagai ADMIN lebih dahulu
    $stmt_admin = mysqli_prepare($conn, "SELECT id, password, nama_lengkap FROM admin_users WHERE username = ? OR id = ?");
    mysqli_stmt_bind_param($stmt_admin, "ss", $input, $input);
    mysqli_stmt_execute($stmt_admin);
    $res_admin = mysqli_stmt_get_result($stmt_admin);

    if ($admin = mysqli_fetch_assoc($res_admin)) {
        if (password_verify($password, $admin['password'])) {
            $_SESSION['admin_logged_in'] = true;
            $_SESSION['admin_id']        = $admin['id'];
            $_SESSION['admin_nama']      = $admin['nama_lengkap'];
            header("Location: ../admin/index.php");
            exit;
        }
    }

    // 2. Cek Login sebagai USER / Masyarakat
    $stmt_user = mysqli_prepare($conn, "SELECT id, nama, password, is_verified FROM users WHERE email = ?");
    mysqli_stmt_bind_param($stmt_user, "s", $input);
    mysqli_stmt_execute($stmt_user);
    $res_user = mysqli_stmt_get_result($stmt_user);

    if ($user = mysqli_fetch_assoc($res_user)) {
        if ($user['is_verified'] == 0) {
            $_SESSION['email_verifikasi'] = $input;
            $_SESSION['error'] = "Akun Anda belum diverifikasi!";
            header("Location: ../pages/verifikasi.php");
            exit;
        }

        if (password_verify($password, $user['password'])) {
            $_SESSION['user_logged_in'] = true;
            $_SESSION['user_id']        = $user['id'];
            $_SESSION['user_nama']      = $user['nama'];
            header("Location: ../index.php");
            exit;
        }
    }

    $_SESSION['error'] = "Email / Username atau Password salah!";
    header("Location: ../pages/login.php");
    exit;
}