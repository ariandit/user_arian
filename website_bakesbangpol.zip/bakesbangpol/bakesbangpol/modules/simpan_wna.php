<?php
require_once __DIR__ . '/../config/koneksi.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nama_wna      = trim($_POST['nama_wna']);
    $kewarganegaraan= trim($_POST['kewarganegaraan']);
    $no_paspor     = trim($_POST['no_paspor']);
    $nama_penjamin = trim($_POST['nama_penjamin']);
    $no_hp_penjamin= trim($_POST['no_hp_penjamin']);
    $alamat_salatiga= trim($_POST['alamat_salatiga']);
    $tujuan_tinggal= trim($_POST['tujuan_tinggal']);

    $nomor_tiket   = 'WNA-' . date('Ym') . '-' . strtoupper(substr(md5(uniqid(rand(), true)), 0, 4));

    $file        = $_FILES['berkas_persyaratan'];
    $fileExt     = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    $newFileName = 'WNA_' . $nomor_tiket . '.' . $fileExt;
    $uploadDir   = __DIR__ . '/../uploads/';

    if (move_uploaded_file($file['tmp_name'], $uploadDir . $newFileName)) {
        $stmt = mysqli_prepare($conn, "INSERT INTO layanan_wna (nomor_tiket, nama_wna, kewarganegaraan, no_paspor, nama_penjamin, no_hp_penjamin, alamat_salatiga, tujuan_tinggal, berkas_persyaratan) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
        mysqli_stmt_bind_param($stmt, "sssssssss", $nomor_tiket, $nama_wna, $kewarganegaraan, $no_paspor, $nama_penjamin, $no_hp_penjamin, $alamat_salatiga, $tujuan_tinggal, $newFileName);

        if (mysqli_stmt_execute($stmt)) {
            echo "<script>alert('Pengajuan SKTT WNA Berhasil!\\n\\nNomor Tiket Anda: " . $nomor_tiket . "'); window.location.href = '../index.php';</script>";
        } else {
            echo "<script>alert('Gagal menyimpan data.'); window.history.back();</script>";
        }
        mysqli_stmt_close($stmt);
    }
}
mysqli_close($conn);
?>