<?php
session_start();
require_once __DIR__ . '/../config/koneksi.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_SESSION['user_id'])) {
    $user_id  = $_SESSION['user_id'];
    $nama     = trim($_POST['nama']);
    $email    = trim($_POST['email']);
    $no_hp    = trim($_POST['no_hp']);
    $password = trim($_POST['password']);

    if (!empty($password)) {
        $hashed_pass = password_hash($password, PASSWORD_DEFAULT);
        $stmt = mysqli_prepare($conn, "UPDATE users SET nama = ?, email = ?, no_hp = ?, password = ? WHERE id = ?");
        mysqli_stmt_bind_param($stmt, "ssssi", $nama, $email, $no_hp, $hashed_pass, $user_id);
    } else {
        $stmt = mysqli_prepare($conn, "UPDATE users SET nama = ?, email = ?, no_hp = ? WHERE id = ?");
        mysqli_stmt_bind_param($stmt, "sssi", $nama, $email, $no_hp, $user_id);
    }

    if (mysqli_stmt_execute($stmt)) {
        $_SESSION['user_nama'] = $nama;
        $_SESSION['pesan']     = "Profil berhasil diperbarui!";
    }
    mysqli_stmt_close($stmt);
    header("Location: ../pages/profile.php");
    exit;
}