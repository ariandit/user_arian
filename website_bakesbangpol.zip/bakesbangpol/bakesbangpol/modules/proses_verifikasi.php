<?php
session_start();
require_once __DIR__ . '/../config/koneksi.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $otp   = trim($_POST['otp']);
    $email = $_SESSION['email_verifikasi'];

    $stmt = mysqli_prepare($conn, "SELECT id, nama FROM users WHERE email = ? AND verification_code = ?");
    mysqli_stmt_bind_param($stmt, "ss", $email, $otp);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    if ($row = mysqli_fetch_assoc($result)) {
        // Aktifkan Akun User
        $update = mysqli_prepare($conn, "UPDATE users SET is_verified = 1, verification_code = NULL WHERE id = ?");
        mysqli_stmt_bind_param($update, "i", $row['id']);
        mysqli_stmt_execute($update);

        // Auto Login User
        $_SESSION['user_logged_in'] = true;
        $_SESSION['user_id']        = $row['id'];
        $_SESSION['user_nama']      = $row['nama'];

        unset($_SESSION['email_verifikasi']);
        unset($_SESSION['otp_simulasi']);

        echo "<script>alert('Verifikasi Berhasil! Akun Anda telah aktif.'); window.location.href = '../index.php';</script>";
    } else {
        $_SESSION['error'] = "Kode verifikasi salah!";
        header("Location: ../pages/verifikasi.php");
        exit;
    }
}