<?php
require_once __DIR__ . '/../config/koneksi.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nama_pemohon = trim($_POST['nama_pemohon']);
    $nik          = trim($_POST['nik']);
    $email        = trim($_POST['email']);
    $no_hp        = trim($_POST['no_hp']);
    $alamat       = trim($_POST['alamat']);
    $rincian      = trim($_POST['rincian_informasi']);
    $tujuan       = trim($_POST['tujuan_penggunaan']);

    $nomor_tiket  = 'PPD-' . date('Ym') . '-' . strtoupper(substr(md5(uniqid(rand(), true)), 0, 4));

    $file        = $_FILES['berkas_ktp'];
    $fileExt     = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    $newFileName = 'PPID_KTP_' . $nomor_tiket . '.' . $fileExt;
    $uploadDir   = __DIR__ . '/../uploads/';

    if (move_uploaded_file($file['tmp_name'], $uploadDir . $newFileName)) {
        $stmt = mysqli_prepare($conn, "INSERT INTO permohonan_ppid (nomor_tiket, nama_pemohon, nik, email, no_hp, alamat, rincian_informasi, tujuan_penggunaan, berkas_ktp) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
        mysqli_stmt_bind_param($stmt, "sssssssss", $nomor_tiket, $nama_pemohon, $nik, $email, $no_hp, $alamat, $rincian, $tujuan, $newFileName);

        if (mysqli_stmt_execute($stmt)) {
            echo "<script>alert('Permohonan Informasi e-PPID Berhasil!\\n\\nNomor Tiket Anda: " . $nomor_tiket . "'); window.location.href = '../index.php';</script>";
        } else {
            echo "<script>alert('Gagal mengirim permohonan.'); window.history.back();</script>";
        }
        mysqli_stmt_close($stmt);
    }
}
mysqli_close($conn);
?>