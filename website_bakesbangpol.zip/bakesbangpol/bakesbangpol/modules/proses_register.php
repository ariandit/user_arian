<?php
session_start();
require_once __DIR__ . '/../config/koneksi.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nama     = trim($_POST['nama']);
    $no_hp    = trim($_POST['no_hp']);
    $email    = trim($_POST['email']);
    $password = password_hash(trim($_POST['password']), PASSWORD_DEFAULT);

    // Cek email ganda
    $cek_email = mysqli_prepare($conn, "SELECT id FROM users WHERE email = ?");
    mysqli_stmt_bind_param($cek_email, "s", $email);
    mysqli_stmt_execute($cek_email);
    if (mysqli_num_rows(mysqli_stmt_get_result($cek_email)) > 0) {
        $_SESSION['error'] = "Email sudah terdaftar. Silakan gunakan email lain atau login.";
        header("Location: ../pages/register.php");
        exit;
    }

    // Generate 6 Digit Kode Verifikasi OTP
    $otp_code = str_pad(rand(0, 999999), 6, '0', STR_PAD_LEFT);

    $stmt = mysqli_prepare($conn, "INSERT INTO users (nama, email, no_hp, password, verification_code, is_verified) VALUES (?, ?, ?, ?, ?, 0)");
    mysqli_stmt_bind_param($stmt, "sssss", $nama, $email, $no_hp, $password, $otp_code);

    if (mysqli_stmt_execute($stmt)) {
        // Kirim email via mail() PHP
        $to      = $email;
        $subject = "Kode Verifikasi Akun Bakesbangpol Salatiga";
        $message = "Halo " . $nama . ",\n\nKode verifikasi akun Anda adalah: " . $otp_code . "\n\nMasukkan kode ini untuk mengaktifkan akun Anda.";
        $headers = "From: no-reply@bakesbangpol.salatiga.go.id";
        @mail($to, $subject, $message, $headers);

        $_SESSION['email_verifikasi'] = $email;
        $_SESSION['otp_simulasi'] = $otp_code; // Untuk mempermudah testing di localhost tanpa mail server
        
        header("Location: ../pages/verifikasi.php");
        exit;
    } else {
        $_SESSION['error'] = "Gagal memproses pendaftaran.";
        header("Location: ../pages/register.php");
        exit;
    }
}